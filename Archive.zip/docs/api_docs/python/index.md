# API reference

This section will be generated when the
[api_generator](https://github.com/tensorflow/docs/tree/master/tools/tensorflow_docs/api_generator)
is configured.
